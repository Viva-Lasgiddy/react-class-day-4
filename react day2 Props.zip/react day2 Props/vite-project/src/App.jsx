
import './App.css'
import Person from './components/Person'

function App() {

  return (
    <>
    <div> 
      <h1>Login</h1>
      <Person name ="Gideon">i like boobs</Person>
      <Person name ="OdumoduBlvck">i like boobs</Person>
      <Person name ="LilWayne">i like boobs</Person>
    </div>
    </>
  )
}

export default App
