const Person = (props) => {
    return (
        <>
            <div> hello ny name is {props.name} i am {Math.floor(Math.random() * 77)} years old</div>
            <div> {props.children}</div>
        </>
    )
}

export default Person