// function Practice(){
// let cars= ["toyota", "nissan", "hyundai", "range rover"]

// const [camry,sentra] = ["toyota","nissan", "hyundai", "range rover" ]
// console.log(sentra)


// function testing (){
//     const display = "data"
//     const testFn =()=>{
//         return 2+2
//     }
//     return[display, testFn]
// }
// const [show,numFn] = testing()
// testing[0]

// // map fuction
// const num= [1,2,3,4,5,6,7,8,9]
// const newArr=[]
// for(let i=0; i < num.length; i++){
//     num[i] = num[i]*2
// }
//     console.log(num)

// const multiplier = num.map((number)=>{return number*2})
// console.log(multiplier)
// console.log(num)
// // spread operator 
// const numOne = [1,2,3,4]
// const numTwo = [5,6,7,8]
// const numThree = [...numOne,...numTwo, 20, 50, 100 ]
// console.log(numThree)

import React from "react"

class App extends React.Component{
    constructor(){
        super();
    }


render(){
    return(
        <>
        </>
    )
}

}
// }
export default Practice