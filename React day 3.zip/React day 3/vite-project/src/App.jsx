import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Practice from './Practice.jsx'
import React, {Component} from 'react'
class App extends Component{
  oruko;
  ojo_ori;
  position;
  costructor(){

  }

state ={
oruko: "engineer",
ojo_ori: 77,
position: "Senior Dev"
product1: "Javascript"
product2: "ReactD5"

}

render(){
  return(
    <>
    <Practice> </Practice>
    </>
  )
}


}
export default App
