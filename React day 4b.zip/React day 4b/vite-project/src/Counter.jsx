import {useState} from "react"

const Counter = (props) =>{
    const [count, setCount] = useState(1)
    return(
        <>
            <h2 className="tag">Hello i am counting {props.children} </h2>
            <div>
                <button onClick={() => setCount(count *5)}>Multiply</button> <button onClick={() => setCount(count +5)}>ConCat</button> <br />
                <h3>{count}</h3>
                <button onClick={()=> setCount(count /5)}>Divide</button> <button onClick={()=> setCount(count -5)}>Subtract</button> <br />
            </div>
        </>
    )
}

export default Counter

